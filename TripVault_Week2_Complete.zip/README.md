# TripVault - Week 2

TripVault is a MERN travel management application. Week 2 adds complete Trip CRUD operations with JWT authentication and ownership protection.

## Features
- User registration and login
- JWT authentication
- Create trips
- View only your own trips
- View one trip
- Edit your own trips
- Delete your own trips with confirmation
- React dashboard with loading, error and empty states
- MongoDB persistence

## Project structure
- `server/` - Node.js + Express + MongoDB API
- `client/` - React + Vite frontend

## Run locally

### 1. Backend
```bash
cd server
npm install
copy .env.example .env
npm run dev
```

For macOS/Linux use:
```bash
cp .env.example .env
```

Edit `.env`:
```env
PORT=5000
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_long_random_secret
```

### 2. Frontend
Open another terminal:
```bash
cd client
npm install
npm run dev
```

Open the URL shown by Vite, normally `http://localhost:5173`.

## API routes

Auth:
- POST `/api/auth/register`
- POST `/api/auth/login`

Trips (JWT required):
- POST `/api/trips`
- GET `/api/trips`
- GET `/api/trips/:id`
- PUT `/api/trips/:id`
- DELETE `/api/trips/:id`

## GitHub submission
Push this Week 2 work to the same public TripVault repository used for Week 1.
