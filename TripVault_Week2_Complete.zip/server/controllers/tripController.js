const mongoose = require("mongoose");
const Trip = require("../models/Trip");

const isOwner = (trip, userId) =>
  trip && trip.user.toString() === userId.toString();

exports.createTrip = async (req, res) => {
  try {
    const { title, destination, startDate, endDate, description, rating } = req.body;

    if (!title || !destination) {
      return res.status(400).json({ message: "Title and destination are required." });
    }

    const trip = await Trip.create({
      title,
      destination,
      startDate: startDate || undefined,
      endDate: endDate || undefined,
      description,
      rating: rating === "" || rating == null ? undefined : Number(rating),
      user: req.user.id
    });

    res.status(201).json(trip);
  } catch (error) {
    res.status(400).json({ message: "Could not create trip.", error: error.message });
  }
};

exports.getTrips = async (req, res) => {
  try {
    const trips = await Trip.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.json(trips);
  } catch (error) {
    res.status(500).json({ message: "Could not fetch trips.", error: error.message });
  }
};

exports.getTrip = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: "Invalid trip ID." });
    }

    const trip = await Trip.findById(req.params.id);

    if (!trip || !isOwner(trip, req.user.id)) {
      return res.status(404).json({ message: "Trip not found." });
    }

    res.json(trip);
  } catch (error) {
    res.status(500).json({ message: "Could not fetch trip.", error: error.message });
  }
};

exports.updateTrip = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: "Invalid trip ID." });
    }

    const trip = await Trip.findById(req.params.id);

    if (!trip || !isOwner(trip, req.user.id)) {
      return res.status(404).json({ message: "Trip not found or not owned by you." });
    }

    const allowed = ["title", "destination", "startDate", "endDate", "description", "rating"];

    allowed.forEach((field) => {
      if (Object.prototype.hasOwnProperty.call(req.body, field)) {
        trip[field] = req.body[field] === "" ? undefined : req.body[field];
      }
    });

    await trip.save();
    res.json(trip);
  } catch (error) {
    res.status(400).json({ message: "Could not update trip.", error: error.message });
  }
};

exports.deleteTrip = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: "Invalid trip ID." });
    }

    const trip = await Trip.findById(req.params.id);

    if (!trip || !isOwner(trip, req.user.id)) {
      return res.status(404).json({ message: "Trip not found or not owned by you." });
    }

    await Trip.findByIdAndDelete(trip._id);
    res.json({ message: "Trip deleted successfully." });
  } catch (error) {
    res.status(500).json({ message: "Could not delete trip.", error: error.message });
  }
};
