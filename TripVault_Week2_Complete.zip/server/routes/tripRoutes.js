const express = require("express");
const protect = require("../middleware/authMiddleware");
const {
  createTrip,
  getTrips,
  getTrip,
  updateTrip,
  deleteTrip
} = require("../controllers/tripController");

const router = express.Router();

router.use(protect);

router.post("/", createTrip);
router.get("/", getTrips);
router.get("/:id", getTrip);
router.put("/:id", updateTrip);
router.delete("/:id", deleteTrip);

module.exports = router;
