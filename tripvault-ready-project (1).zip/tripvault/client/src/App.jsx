import { useEffect, useState } from 'react';
import { Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import api from './api';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';

function ProtectedRoute({ children }) { return localStorage.getItem('tripvault_token') ? children : <Navigate to="/login" replace />; }

export default function App() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  useEffect(() => { if (localStorage.getItem('tripvault_token')) api.get('/auth/me').then(r => setUser(r.data.user)).catch(() => { localStorage.removeItem('tripvault_token'); }); }, []);
  const logout = () => { localStorage.removeItem('tripvault_token'); setUser(null); navigate('/login'); };
  return <div className="app"><header><Link className="brand" to="/">🌍 TripVault</Link>{user && <nav><Link to="/dashboard">Dashboard</Link><button onClick={logout}>Logout</button></nav>}</header><main><Routes><Route path="/" element={<Navigate to={user ? '/dashboard' : '/login'} replace />} /><Route path="/login" element={<Login onLogin={setUser} />} /><Route path="/register" element={<Register />} /><Route path="/dashboard" element={<ProtectedRoute><Dashboard user={user} /></ProtectedRoute>} /><Route path="*" element={<Navigate to="/" replace />} /></Routes></main><footer>TripVault • CodGen Full Stack Internship • Week 1</footer></div>;
}
