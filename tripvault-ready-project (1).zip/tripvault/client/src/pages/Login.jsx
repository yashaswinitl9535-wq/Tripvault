import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api';

export default function Login({ onLogin }) {
  const [form, setForm] = useState({ email: '', password: '' }); const [error, setError] = useState(''); const [loading, setLoading] = useState(false); const navigate = useNavigate();
  const submit = async e => { e.preventDefault(); setError(''); setLoading(true); try { const r = await api.post('/auth/login', form); localStorage.setItem('tripvault_token', r.data.token); onLogin(r.data.user); navigate('/dashboard'); } catch (err) { setError(err.response?.data?.message || 'Login failed'); } finally { setLoading(false); } };
  return <section className="card auth"><div className="logo">🌍</div><h1>Welcome back</h1><p className="muted">Sign in to your TripVault account.</p>{error && <div className="error">{error}</div>}<form onSubmit={submit}><label>Email<input type="email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com" /></label><label>Password<input type="password" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="••••••••" /></label><button className="primary" disabled={loading}>{loading ? 'Signing in...' : 'Login'}</button></form><p className="switch">Don't have an account? <Link to="/register">Create one</Link></p></section>;
}
