import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api';

export default function Register() {
  const [form,setForm]=useState({name:'',email:'',password:''}); const [error,setError]=useState(''); const [success,setSuccess]=useState(''); const [loading,setLoading]=useState(false); const navigate=useNavigate();
  const submit=async e=>{e.preventDefault();setError('');setSuccess('');setLoading(true);try{const r=await api.post('/auth/register',form);setSuccess(r.data.message+' Redirecting to login...');setTimeout(()=>navigate('/login'),900);}catch(err){setError(err.response?.data?.message||'Registration failed');}finally{setLoading(false);}};
  return <section className="card auth"><div className="logo">✈️</div><h1>Create your account</h1><p className="muted">Start saving your travel memories.</p>{error&&<div className="error">{error}</div>}{success&&<div className="success">{success}</div>}<form onSubmit={submit}><label>Full name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Your name" /></label><label>Email<input type="email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com" /></label><label>Password<input type="password" required minLength="6" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="At least 6 characters" /></label><button className="primary" disabled={loading}>{loading?'Creating...':'Register'}</button></form><p className="switch">Already have an account? <Link to="/login">Login</Link></p></section>;
}
