import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import authRoutes from './routes/auth.js';

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.get('/', (req, res) => res.json({ message: 'TripVault API is running', version: '1.0.0' }));
app.use('/api/auth', authRoutes);
app.use((req, res) => res.status(404).json({ message: 'Route not found' }));

if (!process.env.MONGO_URI || !process.env.JWT_SECRET) {
  console.error('Missing MONGO_URI or JWT_SECRET. Create server/.env from .env.example.');
  process.exit(1);
}

mongoose.connect(process.env.MONGO_URI)
  .then(() => app.listen(PORT, () => console.log(`TripVault server running on http://localhost:${PORT}`)))
  .catch(err => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
