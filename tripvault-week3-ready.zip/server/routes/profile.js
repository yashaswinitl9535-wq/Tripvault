const router = require('express').Router();
const User = require('../models/User');
const Trip = require('../models/Trip');
const auth = require('../middleware/authMiddleware');

router.get('/me', auth, async (req, res) => {
  const user = await User.findById(req.user.id).select('-password');
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json(user);
});

router.put('/me', auth, async (req, res) => {
  const { name, bio, profilePicture } = req.body;
  const user = await User.findByIdAndUpdate(
    req.user.id,
    { $set: { name, bio, profilePicture } },
    { new: true, runValidators: true }
  ).select('-password');
  res.json(user);
});

router.get('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('name bio profilePicture createdAt');
    if (!user) return res.status(404).json({ message: 'Profile not found' });
    const trips = await Trip.find({ user: req.params.id }).select('title destination startDate endDate description rating images createdAt').sort({ createdAt: -1 });
    res.json({ user, trips });
  } catch { res.status(400).json({ message: 'Invalid profile id' }); }
});

module.exports = router;
