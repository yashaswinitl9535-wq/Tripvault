const router = require('express').Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Trip = require('../models/Trip');
const auth = require('../middleware/authMiddleware');

const uploadDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}-${Math.round(Math.random()*1e9)}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    if (/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error('Only image files are allowed'));
  }
});

router.use(auth);

router.post('/', async (req, res) => {
  try {
    const trip = await Trip.create({ ...req.body, user: req.user.id });
    res.status(201).json(trip);
  } catch { res.status(400).json({ message: 'Could not create trip' }); }
});

router.get('/', async (req, res) => {
  try {
    const trips = await Trip.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.json(trips);
  } catch { res.status(500).json({ message: 'Could not load trips' }); }
});

router.get('/:id', async (req, res) => {
  try {
    const trip = await Trip.findOne({ _id: req.params.id, user: req.user.id });
    if (!trip) return res.status(404).json({ message: 'Trip not found' });
    res.json(trip);
  } catch { res.status(400).json({ message: 'Invalid trip id' }); }
});

router.put('/:id', async (req, res) => {
  try {
    const trip = await Trip.findOneAndUpdate({ _id: req.params.id, user: req.user.id }, req.body, { new: true, runValidators: true });
    if (!trip) return res.status(404).json({ message: 'Trip not found or not owned by you' });
    res.json(trip);
  } catch { res.status(400).json({ message: 'Could not update trip' }); }
});

router.delete('/:id', async (req, res) => {
  try {
    const trip = await Trip.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    if (!trip) return res.status(404).json({ message: 'Trip not found or not owned by you' });
    res.json({ message: 'Trip deleted' });
  } catch { res.status(400).json({ message: 'Could not delete trip' }); }
});

router.post('/:id/photos', upload.array('photos', 8), async (req, res) => {
  try {
    const trip = await Trip.findOne({ _id: req.params.id, user: req.user.id });
    if (!trip) return res.status(404).json({ message: 'Trip not found or not owned by you' });
    const urls = req.files.map(f => `/uploads/${f.filename}`);
    trip.images.push(...urls);
    await trip.save();
    res.status(201).json(trip);
  } catch (e) { res.status(400).json({ message: e.message || 'Photo upload failed' }); }
});

module.exports = router;
