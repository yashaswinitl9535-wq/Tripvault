# TripVault — CodGen Week 3

TripVault is a MERN travel memory journal. This Week 3 version extends the authentication and trip CRUD foundation with:
- User profiles
- Public profile pages
- Profile editing
- Trip photo upload
- Photo display on trip cards
- Protected APIs using JWT
- Clean React + Express structure

## Tech Stack
React (Vite), React Router, Axios, Node.js, Express, MongoDB Atlas, Mongoose, JWT, bcryptjs, Multer.

## Project Structure
- `client/` — React frontend
- `server/` — Express/MongoDB backend

## Setup

### 1. Backend
```bash
cd server
npm install
```

Create `server/.env`:
```env
MONGO_URI=your_mongodb_atlas_connection_string
JWT_SECRET=your_long_random_secret
PORT=5000
CLIENT_URL=http://localhost:5173
```

Start:
```bash
npm run dev
```

### 2. Frontend
Open another terminal:
```bash
cd client
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## Main APIs
Authentication:
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me`

Trips:
- POST `/api/trips`
- GET `/api/trips`
- GET `/api/trips/:id`
- PUT `/api/trips/:id`
- DELETE `/api/trips/:id`
- POST `/api/trips/:id/photos`

Profiles:
- GET `/api/profile/me`
- PUT `/api/profile/me`
- GET `/api/profile/:id`

## Important
Never commit `.env` or `node_modules`.
