import axios from 'axios';

export const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
export const FILE_BASE = API.replace(/\/api$/, '');

const api = axios.create({ baseURL: API });
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
export default api;
