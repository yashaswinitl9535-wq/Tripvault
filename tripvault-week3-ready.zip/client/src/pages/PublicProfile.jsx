import React,{useEffect,useState} from 'react';
import {useParams} from 'react-router-dom';
import api,{FILE_BASE} from '../api';
export default function PublicProfile(){
 const {id}=useParams();const [data,setData]=useState(null),[err,setErr]=useState('');
 useEffect(()=>{api.get(`/profile/${id}`).then(r=>setData(r.data)).catch(e=>setErr(e.response?.data?.message||'Profile not found'))},[id]);
 if(err)return <main className="container"><div className="card"><p className="error">{err}</p></div></main>;
 if(!data)return <main className="container"><p>Loading profile...</p></main>;
 return <main className="container"><div className="profileHero card">{data.user.profilePicture&&<img className="avatar" src={data.user.profilePicture}/>}<h1>{data.user.name}</h1><p>{data.user.bio||'Traveller & memory collector 🌍'}</p><strong>{data.trips.length} travel memories</strong></div><h2>Shared Memories</h2><div className="tripgrid">{data.trips.map(t=><article className="trip card" key={t._id}>{t.images?.[0]&&<img src={FILE_BASE+t.images[0]} alt={t.title}/>}<h3>{t.title}</h3><p>📍 {t.destination}</p><p>⭐ {t.rating||'Not rated'}</p><p>{t.description}</p>{t.images?.length>1&&<div className="gallery">{t.images.slice(1).map((im,i)=><img key={i} src={FILE_BASE+im} alt={`${t.title} ${i+2}`}/>)}</div>}</article>)}</div></main>
}
