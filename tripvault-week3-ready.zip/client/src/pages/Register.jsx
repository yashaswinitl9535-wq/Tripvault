import React,{useState} from 'react';
import {Link,useNavigate} from 'react-router-dom';
import api from '../api';
export default function Register(){
 const [form,setForm]=useState({name:'',email:'',password:''}); const [error,setError]=useState(''); const nav=useNavigate();
 const submit=async e=>{e.preventDefault();setError('');try{const r=await api.post('/auth/register',form);localStorage.setItem('token',r.data.token);localStorage.setItem('userId',r.data.user.id);nav('/dashboard')}catch(e){setError(e.response?.data?.message||'Registration failed')}};
 return <main className="auth"><div className="card"><h2>Create your TripVault account</h2><form onSubmit={submit}><input placeholder="Full name" required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/><input placeholder="Email" type="email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/><input placeholder="Password (6+ characters)" type="password" minLength="6" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>{error&&<p className="error">{error}</p>}<button className="primary">Register</button></form><p>Already registered? <Link to="/login">Login</Link></p></div></main>
}
