import React,{useState} from 'react';
import {Link,useNavigate} from 'react-router-dom';
import api from '../api';
export default function Login(){
 const [form,setForm]=useState({email:'',password:''}); const [error,setError]=useState(''); const nav=useNavigate();
 const submit=async e=>{e.preventDefault();setError('');try{const r=await api.post('/auth/login',form);localStorage.setItem('token',r.data.token);localStorage.setItem('userId',r.data.user.id);nav('/dashboard')}catch(e){setError(e.response?.data?.message||'Login failed')}};
 return <main className="auth"><div className="card"><h2>Welcome back 👋</h2><form onSubmit={submit}><input placeholder="Email" type="email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/><input placeholder="Password" type="password" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>{error&&<p className="error">{error}</p>}<button className="primary">Login</button></form><p>New here? <Link to="/register">Create account</Link></p></div></main>
}
