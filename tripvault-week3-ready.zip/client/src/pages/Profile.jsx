import React,{useEffect,useState} from 'react';
import api from '../api';
export default function Profile(){
 const [f,setF]=useState({name:'',bio:'',profilePicture:''}),[saved,setSaved]=useState(false);
 useEffect(()=>{api.get('/profile/me').then(r=>setF({name:r.data.name,bio:r.data.bio||'',profilePicture:r.data.profilePicture||''}))},[]);
 const save=async e=>{e.preventDefault();const r=await api.put('/profile/me',f);setF({...f,name:r.data.name,bio:r.data.bio||'',profilePicture:r.data.profilePicture||''});setSaved(true);setTimeout(()=>setSaved(false),2000)};
 const share=`${location.origin}/profile/${localStorage.getItem('userId')}`;
 return <main className="auth"><div className="card"><h2>My Profile 👤</h2><form onSubmit={save}><input value={f.name} required placeholder="Name" onChange={e=>setF({...f,name:e.target.value})}/><input value={f.profilePicture} placeholder="Profile image URL (optional)" onChange={e=>setF({...f,profilePicture:e.target.value})}/><textarea value={f.bio} placeholder="Tell travellers about yourself..." onChange={e=>setF({...f,bio:e.target.value})}/><button className="primary">Save Profile</button></form>{saved&&<p className="success">Profile updated!</p>}<p><strong>Public profile:</strong></p><input readOnly value={share}/></div></main>
}
