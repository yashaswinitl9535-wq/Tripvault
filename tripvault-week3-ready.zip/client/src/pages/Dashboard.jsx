import React,{useEffect,useState} from 'react';
import api,{FILE_BASE} from '../api';

const empty={title:'',destination:'',startDate:'',endDate:'',description:'',rating:5};
export default function Dashboard(){
 const [user,setUser]=useState(null),[trips,setTrips]=useState([]),[form,setForm]=useState(empty),[editing,setEditing]=useState(null),[photos,setPhotos]=useState(null),[msg,setMsg]=useState('');
 const load=async()=>{const [u,t]=await Promise.all([api.get('/auth/me'),api.get('/trips')]);setUser(u.data);setTrips(t.data)};
 useEffect(()=>{load().catch(()=>setMsg('Could not load dashboard'))},[]);
 const save=async e=>{e.preventDefault();try{if(editing) await api.put(`/trips/${editing}`,form);else await api.post('/trips',form);setForm(empty);setEditing(null);await load()}catch(e){setMsg(e.response?.data?.message||'Save failed')}};
 const del=async id=>{if(confirm('Delete this trip?')){await api.delete(`/trips/${id}`);load()}};
 const upload=async id=>{if(!photos?.length)return;const fd=new FormData();[...photos].forEach(p=>fd.append('photos',p));await api.post(`/trips/${id}/photos`,fd);setPhotos(null);document.getElementById('photoInput').value='';load()};
 return <main className="container"><div className="welcome"><div><h1>Hello, {user?.name || 'Traveller'} 👋</h1><p>Your personal travel memory journal.</p></div></div>
 <section className="card"><h2>{editing?'Edit Trip':'Create a New Trip'}</h2><form className="gridform" onSubmit={save}>
 <input placeholder="Trip title" required value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/><input placeholder="Destination" required value={form.destination} onChange={e=>setForm({...form,destination:e.target.value})}/>
 <label>Start date<input type="date" value={form.startDate?.slice(0,10)||''} onChange={e=>setForm({...form,startDate:e.target.value})}/></label><label>End date<input type="date" value={form.endDate?.slice(0,10)||''} onChange={e=>setForm({...form,endDate:e.target.value})}/></label>
 <label>Rating<select value={form.rating} onChange={e=>setForm({...form,rating:Number(e.target.value)})}>{[1,2,3,4,5].map(n=><option key={n}>{n}</option>)}</select></label>
 <textarea placeholder="Describe your memory..." value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/><div><button className="primary">{editing?'Update Trip':'Create Trip'}</button>{editing&&<button type="button" onClick={()=>{setEditing(null);setForm(empty)}}>Cancel</button>}</div></form></section>
 {msg&&<p className="error">{msg}</p>}
 <h2>My Travel Memories ({trips.length})</h2><div className="tripgrid">{trips.map(t=><article className="trip card" key={t._id}>
 {t.images?.[0]&&<img src={FILE_BASE+t.images[0]} alt={t.title}/>}<h3>{t.title}</h3><p>📍 {t.destination}</p><p>⭐ {t.rating||'Not rated'}</p><p>{t.description}</p>
 <div className="actions"><button onClick={()=>{setEditing(t._id);setForm({...t,startDate:t.startDate?.slice(0,10)||'',endDate:t.endDate?.slice(0,10)||''})}}>Edit</button><button onClick={()=>del(t._id)}>Delete</button></div>
 <input id="photoInput" type="file" accept="image/*" multiple onChange={e=>setPhotos(e.target.files)}/><button className="primary small" onClick={()=>upload(t._id)}>Upload Photos</button>
 {t.images?.length>0&&<div className="gallery">{t.images.map((im,i)=><img key={i} src={FILE_BASE+im} alt={`${t.title} ${i+1}`}/>)}</div>}
 </article>)}</div>{trips.length===0&&<div className="empty card">No trips yet. Create your first memory above 🌍</div>}</main>
}
