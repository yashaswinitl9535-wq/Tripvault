import React, {useEffect, useState} from 'react';
import {Routes, Route, Link, Navigate, useNavigate} from 'react-router-dom';
import api from './api';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import PublicProfile from './pages/PublicProfile';

function Nav(){
  const nav=useNavigate();
  const logged=!!localStorage.getItem('token');
  return <nav><Link className="brand" to="/">✈️ TripVault</Link><div>
    {logged ? <><Link to="/dashboard">Dashboard</Link><Link to="/profile">Profile</Link><button className="linkbtn" onClick={()=>{localStorage.clear();nav('/login')}}>Logout</button></> :
    <><Link to="/login">Login</Link><Link to="/register">Register</Link></>}
  </div></nav>
}
function Protected({children}){return localStorage.getItem('token') ? children : <Navigate to="/login" replace/>}
function Home(){return <main className="hero"><h1>Your trips. Your memories. ✨</h1><p>Save your journeys, upload photos, and share your travel memories.</p><Link className="primary" to={localStorage.getItem('token')?'/dashboard':'/register'}>Start Travelling</Link></main>}
export default function App(){return <><Nav/><Routes>
<Route path="/" element={<Home/>}/><Route path="/login" element={<Login/>}/><Route path="/register" element={<Register/>}/>
<Route path="/dashboard" element={<Protected><Dashboard/></Protected>}/><Route path="/profile" element={<Protected><Profile/></Protected>}/>
<Route path="/profile/:id" element={<PublicProfile/>}/>
</Routes></>}
